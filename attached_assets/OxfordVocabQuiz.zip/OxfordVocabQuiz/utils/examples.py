import logging
import random

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Sample template sentences for common words - can be expanded
ENGLISH_TEMPLATES = [
    "I use {} every day.",
    "{} is very important in our daily life.",
    "The teacher explained the meaning of {}.",
    "Many people don't understand the concept of {}.",
    "She likes to talk about {}.",
    "He studies {} at the university.",
    "We need to consider {} in our plans.",
    "They discussed {} during the meeting.",
    "The book contains information about {}.",
    "Learning about {} can be beneficial."
]

TURKISH_TEMPLATES = [
    "Her gün {} kullanıyorum.",
    "{} günlük hayatımızda çok önemlidir.",
    "Öğretmen {} anlamını açıkladı.",
    "Çoğu insan {} kavramını anlamıyor.",
    "O, {} hakkında konuşmayı seviyor.",
    "O, üniversitede {} çalışıyor.",
    "Planlarımızda {} düşünmemiz gerekiyor.",
    "Toplantı sırasında {} hakkında konuştular.",
    "Kitap {} hakkında bilgi içeriyor.",
    "{} hakkında bilgi edinmek faydalı olabilir."
]

def generate_example_sentence(word, translation, lang='en'):
    """
    Generate a simple example sentence for a word
    
    Args:
        word (str): The word to use in the sentence
        translation (str): The translation of the word
        lang (str): Language code ('en' or 'tr')
        
    Returns:
        tuple: A tuple containing (english_sentence, turkish_sentence)
    """
    try:
        if lang == 'en':
            # Generate English example with English word
            template = random.choice(ENGLISH_TEMPLATES)
            english = template.format(word)
            
            # Generate Turkish translation with Turkish word
            corresponding_index = ENGLISH_TEMPLATES.index(template)
            turkish_template = TURKISH_TEMPLATES[corresponding_index]
            turkish = turkish_template.format(translation)
            
        else:  # tr
            # Generate Turkish example with Turkish word
            template = random.choice(TURKISH_TEMPLATES)
            turkish = template.format(translation)
            
            # Generate English translation with English word
            corresponding_index = TURKISH_TEMPLATES.index(template)
            english_template = ENGLISH_TEMPLATES[corresponding_index]
            english = english_template.format(word)
            
        return english, turkish
    except Exception as e:
        logger.error(f"Error generating example sentence for '{word}': {e}")
        return None, None

def generate_examples_for_word(word, translation, count=3):
    """
    Generate multiple example sentences for a word
    
    Args:
        word (str): The English word
        translation (str): The Turkish translation
        count (int): Number of examples to generate
        
    Returns:
        list: List of tuples (english_sentence, turkish_sentence)
    """
    examples = []
    
    # Generate examples in English and Turkish
    for _ in range(count):
        english, turkish = generate_example_sentence(word, translation, 'en')
        if english and turkish:
            examples.append((english, turkish))
    
    return examples