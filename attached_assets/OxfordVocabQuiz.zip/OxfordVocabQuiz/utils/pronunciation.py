import os
import hashlib
from gtts import gTTS
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def generate_pronunciation(word, language='en', save_dir='static/audio'):
    """
    Generate pronunciation MP3 for a word using Google Text-to-Speech
    
    Args:
        word (str): The word to generate pronunciation for
        language (str): Language code ('en' for English, 'tr' for Turkish)
        save_dir (str): Directory to save audio files
        
    Returns:
        str: Relative URL path to the audio file
    """
    try:
        # Create directory if it doesn't exist
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        
        # Generate a filename based on the word and language
        word_hash = hashlib.md5(word.encode()).hexdigest()[:10]
        filename = f"{word_hash}_{language}.mp3"
        filepath = os.path.join(save_dir, filename)
        relative_path = f"/static/audio/{filename}"
        
        # Skip generation if file already exists
        if os.path.exists(filepath):
            logger.info(f"Pronunciation file already exists for '{word}'")
            return relative_path
        
        # Generate pronunciation
        tts = gTTS(text=word, lang=language, slow=False)
        tts.save(filepath)
        logger.info(f"Generated pronunciation for '{word}' in {language}")
        
        return relative_path
    except Exception as e:
        logger.error(f"Error generating pronunciation for '{word}': {e}")
        return None

def batch_generate_pronunciations(words, language='en'):
    """
    Generate pronunciations for a list of words
    
    Args:
        words (list): List of words to generate pronunciations for
        language (str): Language code
        
    Returns:
        dict: Dictionary mapping words to their audio file paths
    """
    results = {}
    
    for word in words:
        path = generate_pronunciation(word, language)
        if path:
            results[word] = path
    
    return results