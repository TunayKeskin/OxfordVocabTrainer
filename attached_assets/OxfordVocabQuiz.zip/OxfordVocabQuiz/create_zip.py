import os
import zipfile

def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            ziph.write(file_path, 
                       os.path.relpath(file_path, 
                                       os.path.join(path, '..')))

if __name__ == '__main__':
    zipf = zipfile.ZipFile('mobile-app.zip', 'w', zipfile.ZIP_DEFLATED)
    zipdir('mobile-app/', zipf)
    zipf.close()
    print("ZIP file 'mobile-app.zip' created successfully!")