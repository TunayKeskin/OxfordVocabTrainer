# İngilizce Türkçe Quiz - Android App

This is the Android application version of the İngilizce Türkçe Quiz web application. It's a bilingual quiz application for learning Oxford 3000/5000 word lists with English-Turkish and Turkish-English quiz modes.

## Features

- **Multiple Quiz Modes:**
  - English to Turkish translation quiz
  - Turkish to English translation quiz
  
- **Word Data:**
  - Includes selected words from Oxford 3000 word list
  - Organized by CEFR levels (A1, A2, B1)
  
- **Quiz Functionality:**
  - Multiple-choice questions
  - Score tracking
  - Results screen with performance statistics

## Building the APK

To build the APK, you'll need:
1. Android Studio
2. JDK 8 or higher
3. Android SDK

### Build Steps:

1. Open the project in Android Studio
2. Sync with Gradle files
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s)
4. Find the APK in mobile-app/app/build/outputs/apk/debug/

## Running on a Device

1. Enable "Unknown sources" in your Android device's settings
2. Copy the APK to your device
3. Open the APK file to install
4. Launch the app from your app drawer