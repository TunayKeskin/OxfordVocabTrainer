@rem Windows batch script to run the Gradle wrapper
@java -jar gradle\wrapper\gradle-wrapper.jar %*