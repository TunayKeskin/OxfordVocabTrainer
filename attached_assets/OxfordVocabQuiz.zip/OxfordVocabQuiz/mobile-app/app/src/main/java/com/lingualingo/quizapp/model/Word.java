package com.lingualingo.quizapp.model;

/**
 * Model class for Word objects
 */
public class Word {
    private int id;
    private String english;
    private String turkish;
    private String wordList;
    private String pronunciationUrl;

    /**
     * Constructor for Word
     *
     * @param id            Word ID
     * @param english       English word
     * @param turkish       Turkish translation
     * @param wordList      Which word list it belongs to (oxford3000 or oxford5000)
     */
    public Word(int id, String english, String turkish, String wordList) {
        this.id = id;
        this.english = english;
        this.turkish = turkish;
        this.wordList = wordList;
    }

    /**
     * Full constructor for Word
     *
     * @param id               Word ID
     * @param english          English word
     * @param turkish          Turkish translation
     * @param wordList         Which word list it belongs to (oxford3000 or oxford5000)
     * @param pronunciationUrl URL to the pronunciation audio file
     */
    public Word(int id, String english, String turkish, String wordList, String pronunciationUrl) {
        this.id = id;
        this.english = english;
        this.turkish = turkish;
        this.wordList = wordList;
        this.pronunciationUrl = pronunciationUrl;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEnglish() {
        return english;
    }

    public void setEnglish(String english) {
        this.english = english;
    }

    public String getTurkish() {
        return turkish;
    }

    public void setTurkish(String turkish) {
        this.turkish = turkish;
    }

    public String getWordList() {
        return wordList;
    }

    public void setWordList(String wordList) {
        this.wordList = wordList;
    }

    public String getPronunciationUrl() {
        return pronunciationUrl;
    }

    public void setPronunciationUrl(String pronunciationUrl) {
        this.pronunciationUrl = pronunciationUrl;
    }

    @Override
    public String toString() {
        return english + " - " + turkish;
    }
}