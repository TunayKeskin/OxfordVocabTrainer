package com.lingualingo.quizapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lingualingo.quizapp.adapter.QuizResultAdapter;
import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.QuizQuestion;
import com.lingualingo.quizapp.model.Word;

import java.util.ArrayList;
import java.util.List;

public class QuizResultFragment extends Fragment {

    private TextView textViewScore;
    private TextView textViewTimeTaken;
    private RecyclerView recyclerViewResults;
    private Button buttonNewQuiz;
    
    private DatabaseHelper dbHelper;
    private long quizAttemptId;
    private List<Word> quizWords;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz_result, container, false);

        // Initialize UI components
        textViewScore = view.findViewById(R.id.textView_score);
        textViewTimeTaken = view.findViewById(R.id.textView_time_taken);
        recyclerViewResults = view.findViewById(R.id.recyclerView_results);
        buttonNewQuiz = view.findViewById(R.id.button_new_quiz);

        dbHelper = new DatabaseHelper(getContext());
        quizWords = new ArrayList<>();

        // Get quiz results from arguments
        Bundle args = getArguments();
        if (args != null) {
            int questionCount = args.getInt("question_count", 0);
            int correctCount = args.getInt("correct_count", 0);
            int timeTaken = args.getInt("time_taken", 0);
            quizAttemptId = args.getLong("quiz_attempt_id", -1);
            String quizMode = args.getString("quiz_mode", "en-tr");

            // Update UI with quiz results
            textViewScore.setText(String.format("Your Score: %d/%d", correctCount, questionCount));
            
            int minutes = timeTaken / 60;
            int seconds = timeTaken % 60;
            textViewTimeTaken.setText(String.format("Time: %d:%02d", minutes, seconds));
        }

        // Set up recycler view
        recyclerViewResults.setLayoutManager(new LinearLayoutManager(getContext()));
        
        // Load quiz words from database
        loadQuizWords();

        // Set up new quiz button
        buttonNewQuiz.setOnClickListener(v -> startNewQuiz());

        return view;
    }

    private void loadQuizWords() {
        // TODO: Implement method to load words from quiz attempt
        // For now, we'll show a simple result list
        QuizResultAdapter adapter = new QuizResultAdapter(getContext(), quizWords);
        recyclerViewResults.setAdapter(adapter);
    }

    private void startNewQuiz() {
        // Navigate back to quiz settings fragment
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, new QuizFragment())
                .commit();
    }
}