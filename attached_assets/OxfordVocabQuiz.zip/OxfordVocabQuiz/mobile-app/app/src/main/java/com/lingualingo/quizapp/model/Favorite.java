package com.lingualingo.quizapp.model;

/**
 * Model class for user favorites
 */
public class Favorite {
    private int id;
    private int wordId;
    private String english;
    private String turkish;
    private String wordList;
    private long createdAt;

    /**
     * Constructor for Favorite
     *
     * @param id       Favorite ID
     * @param wordId   Associated word ID
     * @param english  English word
     * @param turkish  Turkish translation
     * @param wordList Which word list it belongs to
     */
    public Favorite(int id, int wordId, String english, String turkish, String wordList) {
        this.id = id;
        this.wordId = wordId;
        this.english = english;
        this.turkish = turkish;
        this.wordList = wordList;
    }

    /**
     * Full constructor for Favorite
     *
     * @param id        Favorite ID
     * @param wordId    Associated word ID
     * @param english   English word
     * @param turkish   Turkish translation
     * @param wordList  Which word list it belongs to
     * @param createdAt Timestamp when favorite was created
     */
    public Favorite(int id, int wordId, String english, String turkish, String wordList, long createdAt) {
        this.id = id;
        this.wordId = wordId;
        this.english = english;
        this.turkish = turkish;
        this.wordList = wordList;
        this.createdAt = createdAt;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getWordId() {
        return wordId;
    }

    public void setWordId(int wordId) {
        this.wordId = wordId;
    }

    public String getEnglish() {
        return english;
    }

    public void setEnglish(String english) {
        this.english = english;
    }

    public String getTurkish() {
        return turkish;
    }

    public void setTurkish(String turkish) {
        this.turkish = turkish;
    }

    public String getWordList() {
        return wordList;
    }

    public void setWordList(String wordList) {
        this.wordList = wordList;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}