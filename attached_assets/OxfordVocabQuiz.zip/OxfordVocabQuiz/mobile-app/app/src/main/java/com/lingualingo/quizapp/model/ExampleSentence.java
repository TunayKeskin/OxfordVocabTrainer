package com.lingualingo.quizapp.model;

/**
 * Model class for example sentences
 */
public class ExampleSentence {
    private int id;
    private int wordId;
    private String englishSentence;
    private String turkishSentence;

    /**
     * Constructor for ExampleSentence
     *
     * @param id              Example sentence ID
     * @param wordId          Associated word ID
     * @param englishSentence English sentence
     * @param turkishSentence Turkish translation of the sentence
     */
    public ExampleSentence(int id, int wordId, String englishSentence, String turkishSentence) {
        this.id = id;
        this.wordId = wordId;
        this.englishSentence = englishSentence;
        this.turkishSentence = turkishSentence;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getWordId() {
        return wordId;
    }

    public void setWordId(int wordId) {
        this.wordId = wordId;
    }

    public String getEnglishSentence() {
        return englishSentence;
    }

    public void setEnglishSentence(String englishSentence) {
        this.englishSentence = englishSentence;
    }

    public String getTurkishSentence() {
        return turkishSentence;
    }

    public void setTurkishSentence(String turkishSentence) {
        this.turkishSentence = turkishSentence;
    }

    @Override
    public String toString() {
        return englishSentence + "\n" + turkishSentence;
    }
}