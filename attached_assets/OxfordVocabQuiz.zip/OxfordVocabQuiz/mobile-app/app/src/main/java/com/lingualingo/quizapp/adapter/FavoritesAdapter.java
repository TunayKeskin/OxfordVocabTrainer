package com.lingualingo.quizapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lingualingo.quizapp.R;
import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.ExampleSentence;
import com.lingualingo.quizapp.model.Favorite;

import java.util.List;

public class FavoritesAdapter extends RecyclerView.Adapter<FavoritesAdapter.ViewHolder> {

    private final Context context;
    private final List<Favorite> favorites;
    private final DatabaseHelper dbHelper;
    private final OnFavoriteRemovedListener listener;

    public interface OnFavoriteRemovedListener {
        void onFavoriteRemoved(int position);
    }

    public FavoritesAdapter(Context context, List<Favorite> favorites, OnFavoriteRemovedListener listener) {
        this.context = context;
        this.favorites = favorites;
        this.dbHelper = new DatabaseHelper(context);
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_favorite, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Favorite favorite = favorites.get(position);
        
        holder.textViewEnglish.setText(favorite.getEnglish());
        holder.textViewTurkish.setText(favorite.getTurkish());
        
        // Set up pronunciation button
        holder.buttonPlayPronunciation.setOnClickListener(v -> 
                playPronunciation(favorite.getWordId(), favorite.getEnglish()));
        
        // Set up examples button
        holder.buttonShowExamples.setOnClickListener(v -> 
                showExamples(favorite.getWordId()));
        
        // Set up remove button
        holder.buttonRemove.setOnClickListener(v -> 
                removeFavorite(favorite.getId(), position));
    }

    @Override
    public int getItemCount() {
        return favorites.size();
    }

    private void playPronunciation(int wordId, String word) {
        // In a real app, we would play the pronunciation audio here
        Toast.makeText(context, "Playing pronunciation for: " + word, Toast.LENGTH_SHORT).show();
    }

    private void showExamples(int wordId) {
        List<ExampleSentence> examples = dbHelper.getExampleSentences(wordId);
        if (examples.isEmpty()) {
            Toast.makeText(context, "No example sentences available", Toast.LENGTH_SHORT).show();
        } else {
            StringBuilder exampleText = new StringBuilder();
            for (ExampleSentence example : examples) {
                exampleText.append("• ").append(example.getEnglishSentence()).append("\n");
                exampleText.append("• ").append(example.getTurkishSentence()).append("\n\n");
            }
            Toast.makeText(context, exampleText.toString(), Toast.LENGTH_LONG).show();
            // In a real app, we would show this in a dialog or another UI component
        }
    }

    private void removeFavorite(int favoriteId, int position) {
        int result = dbHelper.removeFromFavorites(favoriteId);
        if (result > 0) {
            favorites.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, favorites.size());
            Toast.makeText(context, "Removed from favorites", Toast.LENGTH_SHORT).show();
            
            if (favorites.isEmpty() && listener != null) {
                listener.onFavoriteRemoved(position);
            }
        } else {
            Toast.makeText(context, "Failed to remove from favorites", Toast.LENGTH_SHORT).show();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewEnglish;
        TextView textViewTurkish;
        Button buttonPlayPronunciation;
        Button buttonShowExamples;
        Button buttonRemove;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewEnglish = itemView.findViewById(R.id.textView_english);
            textViewTurkish = itemView.findViewById(R.id.textView_turkish);
            buttonPlayPronunciation = itemView.findViewById(R.id.button_play_pronunciation);
            buttonShowExamples = itemView.findViewById(R.id.button_show_examples);
            buttonRemove = itemView.findViewById(R.id.button_remove);
        }
    }
}