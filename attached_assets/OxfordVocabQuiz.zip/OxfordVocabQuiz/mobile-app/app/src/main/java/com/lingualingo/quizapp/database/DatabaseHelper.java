package com.lingualingo.quizapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.lingualingo.quizapp.model.ExampleSentence;
import com.lingualingo.quizapp.model.Favorite;
import com.lingualingo.quizapp.model.Word;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "lingualingo.db";
    private static final int DATABASE_VERSION = 1;
    private final Context context;

    // Table names
    private static final String TABLE_WORDS = "words";
    private static final String TABLE_EXAMPLE_SENTENCES = "example_sentences";
    private static final String TABLE_FAVORITES = "favorites";
    private static final String TABLE_QUIZ_ATTEMPTS = "quiz_attempts";
    private static final String TABLE_QUIZ_ANSWERS = "quiz_answers";
    private static final String TABLE_USER_STATS = "user_stats";

    // Words table columns
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ENGLISH = "english";
    private static final String COLUMN_TURKISH = "turkish";
    private static final String COLUMN_WORD_LIST = "word_list";
    private static final String COLUMN_PRONUNCIATION_URL = "pronunciation_url";
    
    // Example sentences table columns
    private static final String COLUMN_WORD_ID = "word_id";
    private static final String COLUMN_ENGLISH_SENTENCE = "english_sentence";
    private static final String COLUMN_TURKISH_SENTENCE = "turkish_sentence";
    
    // Favorites table columns
    private static final String COLUMN_CREATED_AT = "created_at";
    
    // Quiz attempts table columns
    private static final String COLUMN_QUIZ_MODE = "quiz_mode";
    private static final String COLUMN_DIFFICULTY = "difficulty";
    private static final String COLUMN_QUESTION_COUNT = "question_count";
    private static final String COLUMN_CORRECT_COUNT = "correct_count";
    private static final String COLUMN_TIME_TAKEN = "time_taken";
    
    // Quiz answers table columns
    private static final String COLUMN_QUIZ_ATTEMPT_ID = "quiz_attempt_id";
    private static final String COLUMN_IS_CORRECT = "is_correct";
    
    // User stats table columns
    private static final String COLUMN_CORRECT_COUNT_STATS = "correct_count";
    private static final String COLUMN_INCORRECT_COUNT = "incorrect_count";
    private static final String COLUMN_LAST_REVIEWED = "last_reviewed";
    private static final String COLUMN_NEXT_REVIEW = "next_review";
    private static final String COLUMN_EASE_FACTOR = "ease_factor";
    private static final String COLUMN_INTERVAL = "interval";

    // Create tables SQL statements
    private static final String SQL_CREATE_WORDS_TABLE =
            "CREATE TABLE " + TABLE_WORDS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ENGLISH + " TEXT NOT NULL, " +
                    COLUMN_TURKISH + " TEXT NOT NULL, " +
                    COLUMN_WORD_LIST + " TEXT NOT NULL, " +
                    COLUMN_PRONUNCIATION_URL + " TEXT)";
    
    private static final String SQL_CREATE_EXAMPLE_SENTENCES_TABLE =
            "CREATE TABLE " + TABLE_EXAMPLE_SENTENCES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WORD_ID + " INTEGER NOT NULL, " +
                    COLUMN_ENGLISH_SENTENCE + " TEXT NOT NULL, " +
                    COLUMN_TURKISH_SENTENCE + " TEXT NOT NULL, " +
                    "FOREIGN KEY(" + COLUMN_WORD_ID + ") REFERENCES " + TABLE_WORDS + "(" + COLUMN_ID + "))";
    
    private static final String SQL_CREATE_FAVORITES_TABLE =
            "CREATE TABLE " + TABLE_FAVORITES + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WORD_ID + " INTEGER NOT NULL, " +
                    COLUMN_CREATED_AT + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_WORD_ID + ") REFERENCES " + TABLE_WORDS + "(" + COLUMN_ID + "))";
    
    private static final String SQL_CREATE_QUIZ_ATTEMPTS_TABLE =
            "CREATE TABLE " + TABLE_QUIZ_ATTEMPTS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_QUIZ_MODE + " TEXT NOT NULL, " +
                    COLUMN_DIFFICULTY + " TEXT NOT NULL, " +
                    COLUMN_WORD_LIST + " TEXT NOT NULL, " +
                    COLUMN_QUESTION_COUNT + " INTEGER NOT NULL, " +
                    COLUMN_CORRECT_COUNT + " INTEGER NOT NULL, " +
                    COLUMN_TIME_TAKEN + " INTEGER, " +
                    COLUMN_CREATED_AT + " INTEGER)";
    
    private static final String SQL_CREATE_QUIZ_ANSWERS_TABLE =
            "CREATE TABLE " + TABLE_QUIZ_ANSWERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_QUIZ_ATTEMPT_ID + " INTEGER NOT NULL, " +
                    COLUMN_WORD_ID + " INTEGER NOT NULL, " +
                    COLUMN_IS_CORRECT + " INTEGER NOT NULL, " +
                    COLUMN_TIME_TAKEN + " REAL, " +
                    COLUMN_CREATED_AT + " INTEGER, " +
                    "FOREIGN KEY(" + COLUMN_QUIZ_ATTEMPT_ID + ") REFERENCES " + TABLE_QUIZ_ATTEMPTS + "(" + COLUMN_ID + "), " +
                    "FOREIGN KEY(" + COLUMN_WORD_ID + ") REFERENCES " + TABLE_WORDS + "(" + COLUMN_ID + "))";
    
    private static final String SQL_CREATE_USER_STATS_TABLE =
            "CREATE TABLE " + TABLE_USER_STATS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_WORD_ID + " INTEGER NOT NULL, " +
                    COLUMN_CORRECT_COUNT_STATS + " INTEGER DEFAULT 0, " +
                    COLUMN_INCORRECT_COUNT + " INTEGER DEFAULT 0, " +
                    COLUMN_LAST_REVIEWED + " INTEGER, " +
                    COLUMN_NEXT_REVIEW + " INTEGER, " +
                    COLUMN_EASE_FACTOR + " REAL DEFAULT 2.5, " +
                    COLUMN_INTERVAL + " INTEGER DEFAULT 0, " +
                    "FOREIGN KEY(" + COLUMN_WORD_ID + ") REFERENCES " + TABLE_WORDS + "(" + COLUMN_ID + "))";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_WORDS_TABLE);
        db.execSQL(SQL_CREATE_EXAMPLE_SENTENCES_TABLE);
        db.execSQL(SQL_CREATE_FAVORITES_TABLE);
        db.execSQL(SQL_CREATE_QUIZ_ATTEMPTS_TABLE);
        db.execSQL(SQL_CREATE_QUIZ_ANSWERS_TABLE);
        db.execSQL(SQL_CREATE_USER_STATS_TABLE);
        
        // Load initial data into the database
        loadInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For simplicity, in the first version we'll just drop and recreate tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_STATS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUIZ_ANSWERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUIZ_ATTEMPTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FAVORITES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXAMPLE_SENTENCES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORDS);
        onCreate(db);
    }

    private void loadInitialData(SQLiteDatabase db) {
        // Load initial word data
        // For a real app, this would be loaded from a CSV file or other resource
        // Here we'll just add a few sample words
        
        // Sample Oxford 3000 words
        String[][] oxford3000Words = {
            {"apple", "elma"},
            {"book", "kitap"},
            {"car", "araba"},
            {"dog", "köpek"},
            {"house", "ev"},
            {"tree", "ağaç"},
            {"water", "su"},
            {"food", "yemek"},
            {"sun", "güneş"},
            {"moon", "ay"}
        };
        
        for (String[] word : oxford3000Words) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ENGLISH, word[0]);
            values.put(COLUMN_TURKISH, word[1]);
            values.put(COLUMN_WORD_LIST, "oxford3000");
            long wordId = db.insert(TABLE_WORDS, null, values);
            
            // Add example sentences for this word
            addSampleExampleSentences(db, (int) wordId, word[0], word[1]);
        }
        
        // Sample Oxford 5000 words
        String[][] oxford5000Words = {
            {"abandon", "terk etmek"},
            {"conceive", "tasarlamak"},
            {"elaborate", "ayrıntılı"},
            {"fascinating", "büyüleyici"},
            {"genuine", "gerçek"},
            {"integrity", "bütünlük"},
            {"negotiate", "müzakere etmek"},
            {"phenomenon", "fenomen"},
            {"territory", "bölge"},
            {"wisdom", "bilgelik"}
        };
        
        for (String[] word : oxford5000Words) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ENGLISH, word[0]);
            values.put(COLUMN_TURKISH, word[1]);
            values.put(COLUMN_WORD_LIST, "oxford5000");
            long wordId = db.insert(TABLE_WORDS, null, values);
            
            // Add example sentences for this word
            addSampleExampleSentences(db, (int) wordId, word[0], word[1]);
        }
    }
    
    private void addSampleExampleSentences(SQLiteDatabase db, int wordId, String english, String turkish) {
        // For a real app, these would be properly translated sentences
        // Here we'll just create some simple examples
        String[][] examples = new String[3][2];
        
        switch (english) {
            case "apple":
                examples[0] = new String[]{"I ate an apple for breakfast.", "Kahvaltıda bir elma yedim."};
                examples[1] = new String[]{"She likes green apples.", "O yeşil elmaları seviyor."};
                examples[2] = new String[]{"The apple tree is in the garden.", "Elma ağacı bahçede."};
                break;
            case "book":
                examples[0] = new String[]{"I read a good book yesterday.", "Dün iyi bir kitap okudum."};
                examples[1] = new String[]{"He has many books in his library.", "Kütüphanesinde birçok kitabı var."};
                examples[2] = new String[]{"She wrote a book about her life.", "Hayatı hakkında bir kitap yazdı."};
                break;
            // Add more examples for each word if needed
            default:
                examples[0] = new String[]{"This is an example with " + english + ".", "Bu " + turkish + " ile bir örnek."};
                examples[1] = new String[]{"How do you use " + english + "?", turkish + " nasıl kullanılır?"};
                examples[2] = new String[]{"I like " + english + ".", turkish + " hoşuma gidiyor."};
                break;
        }
        
        for (String[] example : examples) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_WORD_ID, wordId);
            values.put(COLUMN_ENGLISH_SENTENCE, example[0]);
            values.put(COLUMN_TURKISH_SENTENCE, example[1]);
            db.insert(TABLE_EXAMPLE_SENTENCES, null, values);
        }
    }
    
    public List<Word> getWords(String wordList, int limit) {
        List<Word> words = new ArrayList<>();
        
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_WORD_LIST + " = ?";
        String[] selectionArgs = { wordList };
        String limit_str = String.valueOf(limit);
        
        Cursor cursor = db.query(
            TABLE_WORDS,
            null,
            selection,
            selectionArgs,
            null,
            null,
            "RANDOM()",
            limit_str
        );
        
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String english = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ENGLISH));
                String turkish = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TURKISH));
                String list = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WORD_LIST));
                
                Word word = new Word(id, english, turkish, list);
                words.add(word);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        return words;
    }
    
    public List<ExampleSentence> getExampleSentences(int wordId) {
        List<ExampleSentence> examples = new ArrayList<>();
        
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_WORD_ID + " = ?";
        String[] selectionArgs = { String.valueOf(wordId) };
        
        Cursor cursor = db.query(
            TABLE_EXAMPLE_SENTENCES,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        );
        
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String englishSentence = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ENGLISH_SENTENCE));
                String turkishSentence = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TURKISH_SENTENCE));
                
                ExampleSentence example = new ExampleSentence(id, wordId, englishSentence, turkishSentence);
                examples.add(example);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        return examples;
    }
    
    public long addToFavorites(int wordId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(COLUMN_WORD_ID, wordId);
        values.put(COLUMN_CREATED_AT, System.currentTimeMillis());
        
        return db.insert(TABLE_FAVORITES, null, values);
    }
    
    public int removeFromFavorites(int favoriteId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_ID + " = ?";
        String[] whereArgs = { String.valueOf(favoriteId) };
        
        return db.delete(TABLE_FAVORITES, whereClause, whereArgs);
    }
    
    public List<Favorite> getFavorites() {
        List<Favorite> favorites = new ArrayList<>();
        
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT f." + COLUMN_ID + ", f." + COLUMN_WORD_ID + ", " +
                "w." + COLUMN_ENGLISH + ", w." + COLUMN_TURKISH + ", w." + COLUMN_WORD_LIST + " " +
                "FROM " + TABLE_FAVORITES + " f " +
                "JOIN " + TABLE_WORDS + " w ON f." + COLUMN_WORD_ID + " = w." + COLUMN_ID + " " +
                "ORDER BY f." + COLUMN_CREATED_AT + " DESC";
        
        Cursor cursor = db.rawQuery(query, null);
        
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                int wordId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_WORD_ID));
                String english = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ENGLISH));
                String turkish = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TURKISH));
                String wordList = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WORD_LIST));
                
                Favorite favorite = new Favorite(id, wordId, english, turkish, wordList);
                favorites.add(favorite);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        return favorites;
    }
    
    public long saveQuizAttempt(String quizMode, String difficulty, String wordList, int questionCount, int correctCount, int timeTaken) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(COLUMN_QUIZ_MODE, quizMode);
        values.put(COLUMN_DIFFICULTY, difficulty);
        values.put(COLUMN_WORD_LIST, wordList);
        values.put(COLUMN_QUESTION_COUNT, questionCount);
        values.put(COLUMN_CORRECT_COUNT, correctCount);
        values.put(COLUMN_TIME_TAKEN, timeTaken);
        values.put(COLUMN_CREATED_AT, System.currentTimeMillis());
        
        return db.insert(TABLE_QUIZ_ATTEMPTS, null, values);
    }
    
    public long saveQuizAnswer(long quizAttemptId, int wordId, boolean isCorrect, float timeTaken) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        values.put(COLUMN_QUIZ_ATTEMPT_ID, quizAttemptId);
        values.put(COLUMN_WORD_ID, wordId);
        values.put(COLUMN_IS_CORRECT, isCorrect ? 1 : 0);
        values.put(COLUMN_TIME_TAKEN, timeTaken);
        values.put(COLUMN_CREATED_AT, System.currentTimeMillis());
        
        return db.insert(TABLE_QUIZ_ANSWERS, null, values);
    }
    
    public void updateUserStats(int wordId, boolean isCorrect) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        
        // First, check if a record exists for this word
        String selection = COLUMN_WORD_ID + " = ?";
        String[] selectionArgs = { String.valueOf(wordId) };
        
        Cursor cursor = db.query(
            TABLE_USER_STATS,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        );
        
        if (cursor.moveToFirst()) {
            // Update existing record
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
            int correctCount = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CORRECT_COUNT_STATS));
            int incorrectCount = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_INCORRECT_COUNT));
            float easeFactor = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_EASE_FACTOR));
            int interval = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_INTERVAL));
            
            if (isCorrect) {
                correctCount++;
                // Increase ease factor for correct answers (SM-2 algorithm)
                easeFactor = Math.max(1.3f, easeFactor + 0.1f);
                // Increase interval for spaced repetition
                if (interval == 0) {
                    interval = 1;
                } else if (interval == 1) {
                    interval = 6;
                } else {
                    interval = Math.round(interval * easeFactor);
                }
            } else {
                incorrectCount++;
                // Decrease ease factor for incorrect answers
                easeFactor = Math.max(1.3f, easeFactor - 0.2f);
                // Reset interval for incorrect answers
                interval = 0;
            }
            
            // Calculate next review date
            Calendar calendar = Calendar.getInstance();
            if (interval > 0) {
                calendar.add(Calendar.DAY_OF_MONTH, interval);
            }
            long nextReview = calendar.getTimeInMillis();
            
            values.put(COLUMN_CORRECT_COUNT_STATS, correctCount);
            values.put(COLUMN_INCORRECT_COUNT, incorrectCount);
            values.put(COLUMN_LAST_REVIEWED, System.currentTimeMillis());
            values.put(COLUMN_NEXT_REVIEW, nextReview);
            values.put(COLUMN_EASE_FACTOR, easeFactor);
            values.put(COLUMN_INTERVAL, interval);
            
            String whereClause = COLUMN_ID + " = ?";
            String[] whereArgs = { String.valueOf(id) };
            
            db.update(TABLE_USER_STATS, values, whereClause, whereArgs);
        } else {
            // Create new record
            values.put(COLUMN_WORD_ID, wordId);
            values.put(COLUMN_CORRECT_COUNT_STATS, isCorrect ? 1 : 0);
            values.put(COLUMN_INCORRECT_COUNT, isCorrect ? 0 : 1);
            values.put(COLUMN_LAST_REVIEWED, System.currentTimeMillis());
            
            Calendar calendar = Calendar.getInstance();
            if (isCorrect) {
                calendar.add(Calendar.DAY_OF_MONTH, 1); // Start with 1-day interval for correct answers
                values.put(COLUMN_INTERVAL, 1);
            } else {
                // Review again today for incorrect answers
                values.put(COLUMN_INTERVAL, 0);
            }
            values.put(COLUMN_NEXT_REVIEW, calendar.getTimeInMillis());
            
            // Initial ease factor
            values.put(COLUMN_EASE_FACTOR, 2.5f);
            
            db.insert(TABLE_USER_STATS, null, values);
        }
        
        cursor.close();
    }
    
    public List<Word> getDueWords(int limit) {
        List<Word> dueWords = new ArrayList<>();
        
        SQLiteDatabase db = this.getReadableDatabase();
        long currentTime = System.currentTimeMillis();
        
        String query = "SELECT w.* FROM " + TABLE_WORDS + " w " +
                "JOIN " + TABLE_USER_STATS + " us ON w." + COLUMN_ID + " = us." + COLUMN_WORD_ID + " " +
                "WHERE us." + COLUMN_NEXT_REVIEW + " <= ? " +
                "ORDER BY us." + COLUMN_NEXT_REVIEW + " ASC " +
                "LIMIT ?";
        
        String[] selectionArgs = { String.valueOf(currentTime), String.valueOf(limit) };
        
        Cursor cursor = db.rawQuery(query, selectionArgs);
        
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID));
                String english = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ENGLISH));
                String turkish = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TURKISH));
                String wordList = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WORD_LIST));
                
                Word word = new Word(id, english, turkish, wordList);
                dueWords.add(word);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        
        // If we don't have enough due words, add some random words
        if (dueWords.size() < limit) {
            int additionalWords = limit - dueWords.size();
            
            // Get words that aren't already in the due words list
            List<Integer> existingIds = new ArrayList<>();
            for (Word word : dueWords) {
                existingIds.add(word.getId());
            }
            
            String idsClause = "";
            if (!existingIds.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < existingIds.size(); i++) {
                    sb.append("?");
                    if (i < existingIds.size() - 1) {
                        sb.append(",");
                    }
                }
                idsClause = " WHERE " + COLUMN_ID + " NOT IN (" + sb.toString() + ")";
            }
            
            String randomQuery = "SELECT * FROM " + TABLE_WORDS + idsClause + " ORDER BY RANDOM() LIMIT ?";
            
            String[] randomSelectionArgs;
            if (!existingIds.isEmpty()) {
                randomSelectionArgs = new String[existingIds.size() + 1];
                for (int i = 0; i < existingIds.size(); i++) {
                    randomSelectionArgs[i] = String.valueOf(existingIds.get(i));
                }
                randomSelectionArgs[existingIds.size()] = String.valueOf(additionalWords);
            } else {
                randomSelectionArgs = new String[]{String.valueOf(additionalWords)};
            }
            
            Cursor randomCursor = db.rawQuery(randomQuery, randomSelectionArgs);
            
            if (randomCursor.moveToFirst()) {
                do {
                    int id = randomCursor.getInt(randomCursor.getColumnIndexOrThrow(COLUMN_ID));
                    String english = randomCursor.getString(randomCursor.getColumnIndexOrThrow(COLUMN_ENGLISH));
                    String turkish = randomCursor.getString(randomCursor.getColumnIndexOrThrow(COLUMN_TURKISH));
                    String wordList = randomCursor.getString(randomCursor.getColumnIndexOrThrow(COLUMN_WORD_LIST));
                    
                    Word word = new Word(id, english, turkish, wordList);
                    dueWords.add(word);
                } while (randomCursor.moveToNext());
            }
            
            randomCursor.close();
        }
        
        return dueWords;
    }
    
    // Additional methods for statistics
    public int getTotalQuizAttempts() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_QUIZ_ATTEMPTS, null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        return count;
    }
    
    public float getAverageScore() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT AVG((CAST(" + COLUMN_CORRECT_COUNT + " AS FLOAT) / " + COLUMN_QUESTION_COUNT + ") * 100) " +
                        "FROM " + TABLE_QUIZ_ATTEMPTS, null);
        
        float averageScore = 0;
        if (cursor.moveToFirst()) {
            averageScore = cursor.getFloat(0);
        }
        
        cursor.close();
        return averageScore;
    }
    
    public int getTotalWords() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_WORDS, null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        return count;
    }
    
    public int getMasteredWordsCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_USER_STATS + 
                        " WHERE " + COLUMN_CORRECT_COUNT_STATS + " >= 2 AND " + 
                        COLUMN_INTERVAL + " >= 30", null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        return count;
    }
    
    public int getWordsDueTodayCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        long currentTime = System.currentTimeMillis();
        
        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_USER_STATS + 
                        " WHERE " + COLUMN_NEXT_REVIEW + " <= ?", 
                new String[] { String.valueOf(currentTime) });
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        return count;
    }
    
    public int getFavoriteCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_FAVORITES, null);
        
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        
        cursor.close();
        return count;
    }
}