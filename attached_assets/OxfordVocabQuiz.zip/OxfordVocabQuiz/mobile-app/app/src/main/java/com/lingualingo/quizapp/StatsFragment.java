package com.lingualingo.quizapp;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.lingualingo.quizapp.database.DatabaseHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * Fragment for displaying user statistics
 */
public class StatsFragment extends Fragment {

    private TextView textViewTotalQuizzes;
    private TextView textViewAverageScore;
    private TextView textViewTotalWords;
    private TextView textViewMasteredWords;
    private TextView textViewWordsDueToday;
    private TextView textViewFavoriteCount;
    
    private DatabaseHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_stats, container, false);

        // Initialize UI components
        textViewTotalQuizzes = view.findViewById(R.id.textView_total_quizzes);
        textViewAverageScore = view.findViewById(R.id.textView_average_score);
        textViewTotalWords = view.findViewById(R.id.textView_total_words);
        textViewMasteredWords = view.findViewById(R.id.textView_mastered_words);
        textViewWordsDueToday = view.findViewById(R.id.textView_words_due_today);
        textViewFavoriteCount = view.findViewById(R.id.textView_favorite_count);

        dbHelper = new DatabaseHelper(getContext());

        // Load statistics
        loadStats();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload statistics when returning to this fragment
        loadStats();
    }

    private void loadStats() {
        // Get stats from database
        Map<String, Object> stats = getStats();
        
        // Update UI with stats
        textViewTotalQuizzes.setText(String.valueOf(stats.get("totalQuizzes")));
        textViewAverageScore.setText(String.format("%.1f%%", stats.get("averageScore")));
        textViewTotalWords.setText(String.valueOf(stats.get("totalWords")));
        textViewMasteredWords.setText(String.valueOf(stats.get("masteredWords")));
        textViewWordsDueToday.setText(String.valueOf(stats.get("wordsDueToday")));
        textViewFavoriteCount.setText(String.valueOf(stats.get("favoriteCount")));
    }

    private Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // In a real app, these would be retrieved from the database
        // For now, we'll use some placeholder values
        stats.put("totalQuizzes", dbHelper.getTotalQuizAttempts());
        stats.put("averageScore", dbHelper.getAverageScore());
        stats.put("totalWords", dbHelper.getTotalWords());
        stats.put("masteredWords", dbHelper.getMasteredWordsCount());
        stats.put("wordsDueToday", dbHelper.getWordsDueTodayCount());
        stats.put("favoriteCount", dbHelper.getFavoriteCount());
        
        return stats;
    }
}