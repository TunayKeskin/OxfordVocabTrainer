package com.lingualingo.quizapp;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.QuizQuestion;
import com.lingualingo.quizapp.model.Word;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class QuizQuestionFragment extends Fragment {

    private TextView textViewQuestionNumber;
    private TextView textViewTimer;
    private TextView textViewQuestionWord;
    private Button[] optionButtons;
    private TextView textViewFeedback;
    private Button buttonNext;

    private DatabaseHelper dbHelper;
    private List<QuizQuestion> quizQuestions;
    private int currentQuestionIndex = 0;
    private int correctCount = 0;
    private boolean timedMode;
    private int seconds = 0;
    private Timer timer;
    private String quizMode;
    private String difficulty;
    private String wordList;
    private int questionCount;
    private long quizStartTime;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz_question, container, false);

        // Initialize UI components
        textViewQuestionNumber = view.findViewById(R.id.textView_question_number);
        textViewTimer = view.findViewById(R.id.textView_timer);
        textViewQuestionWord = view.findViewById(R.id.textView_question_word);
        optionButtons = new Button[4];
        optionButtons[0] = view.findViewById(R.id.button_option_1);
        optionButtons[1] = view.findViewById(R.id.button_option_2);
        optionButtons[2] = view.findViewById(R.id.button_option_3);
        optionButtons[3] = view.findViewById(R.id.button_option_4);
        textViewFeedback = view.findViewById(R.id.textView_feedback);
        buttonNext = view.findViewById(R.id.button_next);

        dbHelper = new DatabaseHelper(getContext());

        // Set up option buttons click listeners
        for (int i = 0; i < optionButtons.length; i++) {
            final int index = i;
            optionButtons[i].setOnClickListener(v -> selectAnswer(index));
        }

        // Set up next button click listener
        buttonNext.setOnClickListener(v -> moveToNextQuestion());

        // Get quiz settings from arguments
        Bundle args = getArguments();
        if (args != null) {
            quizMode = args.getString("quiz_mode", "en-tr");
            difficulty = args.getString("difficulty", "easy");
            wordList = args.getString("word_list", "oxford3000");
            timedMode = args.getBoolean("timed_mode", false);
            questionCount = args.getInt("question_count", 10);
        }

        // Set up timer if timed mode is enabled
        if (timedMode) {
            textViewTimer.setVisibility(View.VISIBLE);
            startTimer();
        } else {
            textViewTimer.setVisibility(View.GONE);
        }

        // Generate quiz questions
        generateQuestions();

        // Record quiz start time
        quizStartTime = System.currentTimeMillis();

        // Display first question
        displayQuestion();

        return view;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }

    private void startTimer() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                seconds++;
                new Handler(Looper.getMainLooper()).post(() -> updateTimerDisplay());
            }
        }, 1000, 1000);
    }

    private void updateTimerDisplay() {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        textViewTimer.setText(String.format("Time: %d:%02d", minutes, remainingSeconds));
    }

    private void generateQuestions() {
        quizQuestions = new ArrayList<>();
        List<Word> words = dbHelper.getWords(wordList, questionCount);
        Random random = new Random();

        for (Word word : words) {
            String question;
            String correctAnswer;
            List<String> options = new ArrayList<>();

            if (quizMode.equals("en-tr")) {
                question = word.getEnglish();
                correctAnswer = word.getTurkish();
                options.add(correctAnswer);

                // Get incorrect options based on difficulty
                int optionCount = 3; // Three incorrect options
                int poolSize;
                switch (difficulty) {
                    case "easy":
                        poolSize = 5; // Choose from 5 words
                        break;
                    case "medium":
                        poolSize = 10; // Choose from 10 words
                        break;
                    case "hard":
                    default:
                        poolSize = 15; // Choose from 15 words
                        break;
                }

                // Get incorrect options
                List<Word> incorrectOptions = dbHelper.getWords(wordList, poolSize);
                Collections.shuffle(incorrectOptions);

                int count = 0;
                for (Word incorrectWord : incorrectOptions) {
                    if (!incorrectWord.getTurkish().equals(correctAnswer)) {
                        options.add(incorrectWord.getTurkish());
                        count++;
                        if (count >= optionCount) break;
                    }
                }
            } else { // tr-en mode
                question = word.getTurkish();
                correctAnswer = word.getEnglish();
                options.add(correctAnswer);

                // Get incorrect options based on difficulty
                int optionCount = 3; // Three incorrect options
                int poolSize;
                switch (difficulty) {
                    case "easy":
                        poolSize = 5; // Choose from 5 words
                        break;
                    case "medium":
                        poolSize = 10; // Choose from 10 words
                        break;
                    case "hard":
                    default:
                        poolSize = 15; // Choose from 15 words
                        break;
                }

                // Get incorrect options
                List<Word> incorrectOptions = dbHelper.getWords(wordList, poolSize);
                Collections.shuffle(incorrectOptions);

                int count = 0;
                for (Word incorrectWord : incorrectOptions) {
                    if (!incorrectWord.getEnglish().equals(correctAnswer)) {
                        options.add(incorrectWord.getEnglish());
                        count++;
                        if (count >= optionCount) break;
                    }
                }
            }

            // Shuffle options
            Collections.shuffle(options);

            // Create quiz question
            QuizQuestion quizQuestion = new QuizQuestion(word, question, correctAnswer, options);
            quizQuestions.add(quizQuestion);
        }
    }

    private void displayQuestion() {
        if (currentQuestionIndex < quizQuestions.size()) {
            QuizQuestion currentQuestion = quizQuestions.get(currentQuestionIndex);

            // Update question number
            textViewQuestionNumber.setText(String.format("Question %d/%d", currentQuestionIndex + 1, quizQuestions.size()));

            // Update question word
            textViewQuestionWord.setText(currentQuestion.getQuestion());

            // Update options
            List<String> options = currentQuestion.getOptions();
            for (int i = 0; i < optionButtons.length; i++) {
                if (i < options.size()) {
                    optionButtons[i].setText(options.get(i));
                    optionButtons[i].setEnabled(true);
                    optionButtons[i].setBackgroundResource(R.drawable.button_background);
                } else {
                    optionButtons[i].setVisibility(View.GONE);
                }
            }

            // Reset feedback and next button
            textViewFeedback.setText("Select an answer");
            buttonNext.setEnabled(false);
            
            // Record question start time
            currentQuestion.setStartTime(System.currentTimeMillis());
        } else {
            finishQuiz();
        }
    }

    private void selectAnswer(int optionIndex) {
        QuizQuestion currentQuestion = quizQuestions.get(currentQuestionIndex);
        
        // If already answered, do nothing
        if (currentQuestion.isAnswered()) {
            return;
        }
        
        String selectedAnswer = optionButtons[optionIndex].getText().toString();
        currentQuestion.setSelectedAnswer(selectedAnswer);
        
        // Update UI based on correctness
        boolean isCorrect = currentQuestion.isCorrect();
        
        if (isCorrect) {
            correctCount++;
            highlightButton(optionButtons[optionIndex], true);
            textViewFeedback.setText(getString(R.string.correct));
            textViewFeedback.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorCorrect));
        } else {
            highlightButton(optionButtons[optionIndex], false);
            
            // Find and highlight the correct answer
            for (int i = 0; i < optionButtons.length; i++) {
                if (optionButtons[i].getText().toString().equals(currentQuestion.getCorrectAnswer())) {
                    highlightButton(optionButtons[i], true);
                    break;
                }
            }
            
            textViewFeedback.setText(getString(R.string.incorrect));
            textViewFeedback.setTextColor(ContextCompat.getColor(requireContext(), R.color.colorIncorrect));
        }
        
        // Update user stats in database
        dbHelper.updateUserStats(currentQuestion.getWord().getId(), isCorrect);
        
        // Disable all option buttons
        for (Button button : optionButtons) {
            button.setEnabled(false);
        }
        
        // Enable next button
        buttonNext.setEnabled(true);
    }

    private void highlightButton(Button button, boolean isCorrect) {
        Context context = getContext();
        if (context == null) return;
        
        int colorFrom = ContextCompat.getColor(context, R.color.colorPrimary);
        int colorTo = isCorrect 
                ? ContextCompat.getColor(context, R.color.colorCorrect) 
                : ContextCompat.getColor(context, R.color.colorIncorrect);
        
        ValueAnimator colorAnimation = ValueAnimator.ofObject(new ArgbEvaluator(), colorFrom, colorTo);
        colorAnimation.setDuration(300);
        colorAnimation.addUpdateListener(animator -> button.setBackgroundColor((int) animator.getAnimatedValue()));
        colorAnimation.start();
    }

    private void moveToNextQuestion() {
        currentQuestionIndex++;
        displayQuestion();
    }

    private void finishQuiz() {
        // Calculate total time taken
        long quizEndTime = System.currentTimeMillis();
        int timeTaken = (int) ((quizEndTime - quizStartTime) / 1000);
        
        // Save quiz attempt in database
        long quizAttemptId = dbHelper.saveQuizAttempt(
                quizMode, 
                difficulty, 
                wordList, 
                quizQuestions.size(), 
                correctCount, 
                timedMode ? seconds : timeTaken);
        
        // Save individual answers
        for (QuizQuestion question : quizQuestions) {
            dbHelper.saveQuizAnswer(
                    quizAttemptId,
                    question.getWord().getId(),
                    question.isCorrect(),
                    question.getTimeTaken());
        }
        
        // Create bundle with quiz results
        Bundle args = new Bundle();
        args.putInt("question_count", quizQuestions.size());
        args.putInt("correct_count", correctCount);
        args.putInt("time_taken", timedMode ? seconds : timeTaken);
        args.putLong("quiz_attempt_id", quizAttemptId);
        args.putString("quiz_mode", quizMode);
        
        // Navigate to results fragment
        QuizResultFragment resultFragment = new QuizResultFragment();
        resultFragment.setArguments(args);
        
        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, resultFragment)
                .commit();
    }
}