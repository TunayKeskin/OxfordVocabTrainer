package com.lingualingo.quizapp.model;

import java.io.Serializable;

public class QuizAttempt implements Serializable {
    private int id;
    private String quizMode;
    private String difficulty;
    private String wordList;
    private int questionCount;
    private int correctCount;
    private Integer timeTaken;
    private String createdAt;

    public QuizAttempt() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getQuizMode() {
        return quizMode;
    }

    public void setQuizMode(String quizMode) {
        this.quizMode = quizMode;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public String getWordList() {
        return wordList;
    }

    public void setWordList(String wordList) {
        this.wordList = wordList;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    public int getCorrectCount() {
        return correctCount;
    }

    public void setCorrectCount(int correctCount) {
        this.correctCount = correctCount;
    }

    public Integer getTimeTaken() {
        return timeTaken;
    }

    public void setTimeTaken(Integer timeTaken) {
        this.timeTaken = timeTaken;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getScoreText() {
        return correctCount + "/" + questionCount;
    }
    
    public String getTimeText() {
        if (timeTaken == null) return "N/A";
        
        int minutes = timeTaken / 60;
        int seconds = timeTaken % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}