package com.lingualingo.quizapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.lingualingo.quizapp.R;
import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.ExampleSentence;
import com.lingualingo.quizapp.model.Word;

import java.util.List;

public class QuizResultAdapter extends RecyclerView.Adapter<QuizResultAdapter.ViewHolder> {

    private final Context context;
    private final List<Word> words;
    private final DatabaseHelper dbHelper;

    public QuizResultAdapter(Context context, List<Word> words) {
        this.context = context;
        this.words = words;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_quiz_result, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Word word = words.get(position);
        
        holder.textViewQuestionWord.setText(word.getEnglish());
        holder.textViewCorrectAnswer.setText(word.getTurkish());
        
        // Set up action buttons
        holder.buttonPlayPronunciation.setOnClickListener(v -> playPronunciation(word));
        holder.buttonShowExamples.setOnClickListener(v -> showExamples(word));
        holder.buttonAddFavorite.setOnClickListener(v -> addToFavorites(word));
    }

    @Override
    public int getItemCount() {
        return words.size();
    }

    private void playPronunciation(Word word) {
        // In a real app, we would play the pronunciation audio here
        Toast.makeText(context, "Playing pronunciation for: " + word.getEnglish(), Toast.LENGTH_SHORT).show();
    }

    private void showExamples(Word word) {
        List<ExampleSentence> examples = dbHelper.getExampleSentences(word.getId());
        if (examples.isEmpty()) {
            Toast.makeText(context, "No example sentences available", Toast.LENGTH_SHORT).show();
        } else {
            StringBuilder exampleText = new StringBuilder();
            for (ExampleSentence example : examples) {
                exampleText.append("• ").append(example.getEnglishSentence()).append("\n");
                exampleText.append("• ").append(example.getTurkishSentence()).append("\n\n");
            }
            Toast.makeText(context, exampleText.toString(), Toast.LENGTH_LONG).show();
            // In a real app, we would show this in a dialog or another UI component
        }
    }

    private void addToFavorites(Word word) {
        long result = dbHelper.addToFavorites(word.getId());
        if (result > 0) {
            Toast.makeText(context, "Added to favorites", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Failed to add to favorites", Toast.LENGTH_SHORT).show();
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewQuestionWord;
        TextView textViewCorrectAnswer;
        TextView textViewYourAnswer;
        ImageView imageViewStatus;
        LinearLayout linearLayoutActions;
        Button buttonPlayPronunciation;
        Button buttonShowExamples;
        Button buttonAddFavorite;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewQuestionWord = itemView.findViewById(R.id.textView_question_word);
            textViewCorrectAnswer = itemView.findViewById(R.id.textView_correct_answer);
            textViewYourAnswer = itemView.findViewById(R.id.textView_your_answer);
            imageViewStatus = itemView.findViewById(R.id.imageView_status);
            linearLayoutActions = itemView.findViewById(R.id.linearLayout_actions);
            buttonPlayPronunciation = itemView.findViewById(R.id.button_play_pronunciation);
            buttonShowExamples = itemView.findViewById(R.id.button_show_examples);
            buttonAddFavorite = itemView.findViewById(R.id.button_add_favorite);
        }
    }
}