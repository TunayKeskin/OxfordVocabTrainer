package com.lingualingo.quizapp.model;

import java.util.List;

/**
 * Model class representing a quiz question
 */
public class QuizQuestion {
    private Word word;
    private String question;
    private String correctAnswer;
    private List<String> options;
    private String selectedAnswer;
    private long startTime;
    private long endTime;

    /**
     * Constructor for QuizQuestion
     *
     * @param word          The Word object associated with this question
     * @param question      The question text
     * @param correctAnswer The correct answer
     * @param options       List of answer options (including the correct one)
     */
    public QuizQuestion(Word word, String question, String correctAnswer, List<String> options) {
        this.word = word;
        this.question = question;
        this.correctAnswer = correctAnswer;
        this.options = options;
    }

    /**
     * Set the time when user started viewing this question
     *
     * @param startTime Timestamp in milliseconds
     */
    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    /**
     * Set the answer selected by the user
     *
     * @param selectedAnswer The user's selected answer
     */
    public void setSelectedAnswer(String selectedAnswer) {
        this.selectedAnswer = selectedAnswer;
        this.endTime = System.currentTimeMillis(); // Record the end time when answer is selected
    }

    /**
     * Check if the user's answer is correct
     *
     * @return true if correct, false otherwise
     */
    public boolean isCorrect() {
        return correctAnswer.equals(selectedAnswer);
    }

    /**
     * Check if the question has been answered
     *
     * @return true if answered, false otherwise
     */
    public boolean isAnswered() {
        return selectedAnswer != null;
    }

    /**
     * Get the time taken to answer this question in seconds
     *
     * @return Time taken in seconds
     */
    public float getTimeTaken() {
        if (startTime == 0 || endTime == 0) {
            return 0;
        }
        return (endTime - startTime) / 1000f;
    }

    // Getters and setters
    public Word getWord() {
        return word;
    }

    public void setWord(Word word) {
        this.word = word;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }

    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public String getSelectedAnswer() {
        return selectedAnswer;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }
}