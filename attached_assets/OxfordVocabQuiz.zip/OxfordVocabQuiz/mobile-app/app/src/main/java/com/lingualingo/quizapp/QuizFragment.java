package com.lingualingo.quizapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class QuizFragment extends Fragment {

    private RadioGroup radioGroupMode;
    private RadioGroup radioGroupDifficulty;
    private RadioGroup radioGroupWordList;
    private Switch switchTimedMode;
    private SeekBar seekBarQuestionCount;
    private TextView textViewQuestionCount;
    private Button buttonStartQuiz;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        // Initialize UI components
        radioGroupMode = view.findViewById(R.id.radioGroup_mode);
        radioGroupDifficulty = view.findViewById(R.id.radioGroup_difficulty);
        radioGroupWordList = view.findViewById(R.id.radioGroup_word_list);
        switchTimedMode = view.findViewById(R.id.switch_timed_mode);
        seekBarQuestionCount = view.findViewById(R.id.seekBar_question_count);
        textViewQuestionCount = view.findViewById(R.id.textView_question_count);
        buttonStartQuiz = view.findViewById(R.id.button_start_quiz);

        // Set up question count seekbar
        seekBarQuestionCount.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Add 5 to get a minimum of 5 questions
                int questionCount = progress + 5;
                textViewQuestionCount.setText(String.valueOf(questionCount));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No action needed
            }
        });

        // Set up start quiz button
        buttonStartQuiz.setOnClickListener(v -> startQuiz());

        // Default selection for question count
        seekBarQuestionCount.setProgress(5); // Default to 10 questions (5 + 5)
        textViewQuestionCount.setText("10");

        return view;
    }

    private void startQuiz() {
        // Get quiz settings from UI
        String quizMode = getSelectedMode();
        String difficulty = getSelectedDifficulty();
        String wordList = getSelectedWordList();
        boolean timedMode = switchTimedMode.isChecked();
        int questionCount = seekBarQuestionCount.getProgress() + 5;

        // Create bundle with quiz settings
        Bundle args = new Bundle();
        args.putString("quiz_mode", quizMode);
        args.putString("difficulty", difficulty);
        args.putString("word_list", wordList);
        args.putBoolean("timed_mode", timedMode);
        args.putInt("question_count", questionCount);

        // Navigate to quiz question fragment
        QuizQuestionFragment quizQuestionFragment = new QuizQuestionFragment();
        quizQuestionFragment.setArguments(args);

        getParentFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, quizQuestionFragment)
                .commit();
    }

    private String getSelectedMode() {
        int selectedId = radioGroupMode.getCheckedRadioButtonId();
        RadioButton radioButton = getView().findViewById(selectedId);
        if (radioButton == null) {
            return "en-tr"; // Default to English to Turkish
        }
        
        String mode = radioButton.getText().toString();
        // Convert text to actual mode value
        if (mode.contains("English → Turkish")) {
            return "en-tr";
        } else {
            return "tr-en";
        }
    }

    private String getSelectedDifficulty() {
        int selectedId = radioGroupDifficulty.getCheckedRadioButtonId();
        RadioButton radioButton = getView().findViewById(selectedId);
        if (radioButton == null) {
            return "medium"; // Default to medium difficulty
        }
        
        String difficulty = radioButton.getText().toString().toLowerCase();
        // Ensure it's one of our expected values
        if (difficulty.contains("easy")) {
            return "easy";
        } else if (difficulty.contains("medium")) {
            return "medium";
        } else {
            return "hard";
        }
    }

    private String getSelectedWordList() {
        int selectedId = radioGroupWordList.getCheckedRadioButtonId();
        RadioButton radioButton = getView().findViewById(selectedId);
        if (radioButton == null) {
            return "oxford3000"; // Default to Oxford 3000
        }
        
        String wordList = radioButton.getText().toString();
        // Convert text to actual word list value
        if (wordList.contains("3000")) {
            return "oxford3000";
        } else if (wordList.contains("5000")) {
            return "oxford5000";
        } else {
            return "combined";
        }
    }
}