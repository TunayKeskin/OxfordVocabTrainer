package com.lingualingo.quizapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.lingualingo.quizapp.adapter.FavoritesAdapter;
import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.Favorite;

import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerViewFavorites;
    private TextView textViewNoFavorites;
    
    private DatabaseHelper dbHelper;
    private FavoritesAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_favorites, container, false);

        // Initialize UI components
        recyclerViewFavorites = view.findViewById(R.id.recyclerView_favorites);
        textViewNoFavorites = view.findViewById(R.id.textView_no_favorites);

        dbHelper = new DatabaseHelper(getContext());

        // Set up recycler view
        recyclerViewFavorites.setLayoutManager(new LinearLayoutManager(getContext()));

        // Load favorites
        loadFavorites();

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Reload favorites when returning to this fragment
        loadFavorites();
    }

    private void loadFavorites() {
        List<Favorite> favorites = dbHelper.getFavorites();
        
        if (favorites.isEmpty()) {
            recyclerViewFavorites.setVisibility(View.GONE);
            textViewNoFavorites.setVisibility(View.VISIBLE);
        } else {
            recyclerViewFavorites.setVisibility(View.VISIBLE);
            textViewNoFavorites.setVisibility(View.GONE);
            
            adapter = new FavoritesAdapter(getContext(), favorites, this::onFavoriteRemoved);
            recyclerViewFavorites.setAdapter(adapter);
        }
    }

    private void onFavoriteRemoved(int position) {
        loadFavorites(); // Reload favorites after removal
    }
}