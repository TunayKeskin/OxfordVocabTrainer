package com.lingualingo.quizapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.lingualingo.quizapp.database.DatabaseHelper;
import com.lingualingo.quizapp.model.Word;

import java.util.List;

/**
 * Fragment for spaced repetition review
 */
public class ReviewFragment extends Fragment {

    private TextView textViewQuestion;
    private Button buttonShowAnswer;
    private TextView textViewAnswer;
    private Button buttonEasy;
    private Button buttonMedium;
    private Button buttonHard;
    private TextView textViewProgress;
    private Button buttonPlayPronunciation;
    private Button buttonShowExamples;
    
    private DatabaseHelper dbHelper;
    private List<Word> dueWords;
    private int currentWordIndex = 0;
    private int totalReviewedCount = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_review, container, false);

        // Initialize UI components
        textViewQuestion = view.findViewById(R.id.textView_question);
        buttonShowAnswer = view.findViewById(R.id.button_show_answer);
        textViewAnswer = view.findViewById(R.id.textView_answer);
        buttonEasy = view.findViewById(R.id.button_easy);
        buttonMedium = view.findViewById(R.id.button_medium);
        buttonHard = view.findViewById(R.id.button_hard);
        textViewProgress = view.findViewById(R.id.textView_progress);
        buttonPlayPronunciation = view.findViewById(R.id.button_play_pronunciation);
        buttonShowExamples = view.findViewById(R.id.button_show_examples);

        dbHelper = new DatabaseHelper(getContext());

        // Set up button click listeners
        buttonShowAnswer.setOnClickListener(v -> showAnswer());
        buttonEasy.setOnClickListener(v -> rateWord(3));
        buttonMedium.setOnClickListener(v -> rateWord(2));
        buttonHard.setOnClickListener(v -> rateWord(1));
        buttonPlayPronunciation.setOnClickListener(v -> playPronunciation());
        buttonShowExamples.setOnClickListener(v -> showExamples());

        // Initial state of buttons
        buttonEasy.setEnabled(false);
        buttonMedium.setEnabled(false);
        buttonHard.setEnabled(false);
        buttonPlayPronunciation.setEnabled(false);
        buttonShowExamples.setEnabled(false);

        // Load due words
        loadDueWords();

        return view;
    }

    private void loadDueWords() {
        // Get words due for review from the database
        dueWords = dbHelper.getDueWords(20); // Limit to 20 words per session
        
        if (dueWords.isEmpty()) {
            // No words due for review
            textViewQuestion.setText("No words due for review!");
            buttonShowAnswer.setEnabled(false);
            textViewProgress.setText("0/0");
        } else {
            // Display the first word
            currentWordIndex = 0;
            totalReviewedCount = 0;
            displayCurrentWord();
        }
    }

    private void displayCurrentWord() {
        if (currentWordIndex < dueWords.size()) {
            Word currentWord = dueWords.get(currentWordIndex);
            
            // Update UI for the current word
            textViewQuestion.setText(currentWord.getEnglish());
            textViewAnswer.setText("");
            textViewAnswer.setVisibility(View.GONE);
            
            // Reset UI state
            buttonShowAnswer.setEnabled(true);
            buttonEasy.setEnabled(false);
            buttonMedium.setEnabled(false);
            buttonHard.setEnabled(false);
            buttonPlayPronunciation.setEnabled(true);
            buttonShowExamples.setEnabled(true);
            
            // Update progress
            textViewProgress.setText(String.format("%d/%d", totalReviewedCount, dueWords.size()));
        } else {
            // All words reviewed
            textViewQuestion.setText("Review complete!");
            textViewAnswer.setText("");
            textViewAnswer.setVisibility(View.GONE);
            buttonShowAnswer.setEnabled(false);
            buttonEasy.setEnabled(false);
            buttonMedium.setEnabled(false);
            buttonHard.setEnabled(false);
            buttonPlayPronunciation.setEnabled(false);
            buttonShowExamples.setEnabled(false);
            textViewProgress.setText(String.format("%d/%d", totalReviewedCount, dueWords.size()));
        }
    }

    private void showAnswer() {
        if (currentWordIndex < dueWords.size()) {
            Word currentWord = dueWords.get(currentWordIndex);
            textViewAnswer.setText(currentWord.getTurkish());
            textViewAnswer.setVisibility(View.VISIBLE);
            
            // Enable rating buttons
            buttonShowAnswer.setEnabled(false);
            buttonEasy.setEnabled(true);
            buttonMedium.setEnabled(true);
            buttonHard.setEnabled(true);
        }
    }

    private void rateWord(int difficulty) {
        if (currentWordIndex < dueWords.size()) {
            Word currentWord = dueWords.get(currentWordIndex);
            
            // Update word rating in the database
            boolean isCorrect = difficulty > 1; // Medium and Easy count as correct
            dbHelper.updateUserStats(currentWord.getId(), isCorrect);
            
            // Move to the next word
            currentWordIndex++;
            totalReviewedCount++;
            displayCurrentWord();
        }
    }

    private void playPronunciation() {
        if (currentWordIndex < dueWords.size()) {
            Word currentWord = dueWords.get(currentWordIndex);
            
            // Play pronunciation
            Toast.makeText(getContext(), "Playing pronunciation for: " + currentWord.getEnglish(), Toast.LENGTH_SHORT).show();
            // In a real app, we would use Android's TextToSpeech or play a downloaded audio file
        }
    }

    private void showExamples() {
        if (currentWordIndex < dueWords.size()) {
            Word currentWord = dueWords.get(currentWordIndex);
            
            // Show examples
            StringBuilder exampleText = new StringBuilder();
            dbHelper.getExampleSentences(currentWord.getId()).forEach(example -> {
                exampleText.append("• ").append(example.getEnglishSentence()).append("\n");
                exampleText.append("• ").append(example.getTurkishSentence()).append("\n\n");
            });
            
            if (exampleText.length() > 0) {
                Toast.makeText(getContext(), exampleText.toString(), Toast.LENGTH_LONG).show();
                // In a real app, we would show this in a dialog
            } else {
                Toast.makeText(getContext(), "No examples available", Toast.LENGTH_SHORT).show();
            }
        }
    }
}