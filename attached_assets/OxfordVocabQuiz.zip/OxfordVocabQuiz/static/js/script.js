// Global variables
let words = {}; // Will store our word lists
let settings = {
    wordList: 'oxford3000',
    difficulty: 'easy',
    questionCount: 10,
    timedMode: false,
    timeLimit: 30 // seconds per question
};
let stats = {
    completedQuizzes: 0,
    learnedWords: 0,
    correctAnswers: 0,
    totalQuestions: 0,
    avgTimePerQuestion: 0,
    dueForReview: 0,
    favorites: []
};
let currentQuiz = {
    mode: '',
    questions: [],
    currentQuestionIndex: 0,
    score: 0,
    selectedOptions: [],
    startTime: null,
    endTime: null,
    questionStartTime: null,
    questionsTimes: [],
    totalTime: 0,
    timer: null
};

// Initialize the application
document.addEventListener('DOMContentLoaded', async function() {
    // Load settings from localStorage
    loadSettings();
    
    // Load statistics from localStorage
    loadStats();
    
    // Load word lists
    await loadWordLists();
    
    // Check if user is logged in
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('.user-info') !== null;
    
    if (isLoggedIn) {
        // Add class to body for logged in state
        document.body.classList.add('logged-in');
        
        // Load user data from server
        await Promise.all([
            loadUserStats(),
            loadFavorites(),
            loadDueWords()
        ]);
    } else {
        // Update stats display from localStorage
        updateStatsDisplay();
    }
    
    // Add timed mode option to settings if it doesn't exist
    const settingsContainer = document.querySelector('.settings-container');
    if (settingsContainer && !document.querySelector('.settings-section [data-setting="timedMode"]')) {
        const timedModeSection = document.createElement('div');
        timedModeSection.className = 'settings-section';
        timedModeSection.innerHTML = `
            <div class="settings-section-title">Zamanlı Quiz</div>
            <div class="settings-options">
                <div class="settings-option ${settings.timedMode ? '' : 'settings-option-active'}" 
                     data-value="false" 
                     data-setting="timedMode" 
                     onclick="toggleTimedMode(this, false)">Kapalı</div>
                <div class="settings-option ${settings.timedMode ? 'settings-option-active' : ''}" 
                     data-value="true" 
                     data-setting="timedMode" 
                     onclick="toggleTimedMode(this, true)">Açık</div>
            </div>
        `;
        
        // Add before the button container
        const buttonContainer = settingsContainer.querySelector('.button-container');
        settingsContainer.insertBefore(timedModeSection, buttonContainer);
    }
});

// Toggle timed mode setting
function toggleTimedMode(element, value) {
    // Remove active class from all options in the same section
    const optionsContainer = element.parentElement;
    optionsContainer.querySelectorAll('.settings-option').forEach(option => {
        option.classList.remove('settings-option-active');
    });
    
    // Add active class to the selected option
    element.classList.add('settings-option-active');
    
    // Update settings
    settings.timedMode = value;
}

// Load word lists from JSON files
async function loadWordLists() {
    try {
        // Get word lists from the API (with IDs)
        const oxford3000Response = await fetch('/api/words?list=oxford3000');
        const oxford5000Response = await fetch('/api/words?list=oxford5000');
        
        if (!oxford3000Response.ok || !oxford5000Response.ok) {
            throw new Error('Failed to load word lists from API');
        }
        
        words.oxford3000 = await oxford3000Response.json();
        words.oxford5000 = await oxford5000Response.json();
        
        // Create combined word list
        words.combined = [...words.oxford3000, ...words.oxford5000];
        
        console.log('Word lists loaded successfully');
    } catch (error) {
        console.error('Error loading word lists:', error);
        
        // Fallback to static JSON files if API fails
        try {
            const oxford3000Response = await fetch('/static/data/oxford3000.json');
            const oxford5000Response = await fetch('/static/data/oxford5000.json');
            
            if (!oxford3000Response.ok || !oxford5000Response.ok) {
                throw new Error('Failed to load word lists from static files');
            }
            
            words.oxford3000 = await oxford3000Response.json();
            words.oxford5000 = await oxford5000Response.json();
            
            // Create combined word list
            words.combined = [...words.oxford3000, ...words.oxford5000];
            
            console.log('Word lists loaded from static files');
        } catch (fallbackError) {
            console.error('Error loading word lists from static files:', fallbackError);
            alert('Kelime listeleri yüklenirken bir hata oluştu. Lütfen sayfayı yenileyin.');
        }
    }
}

// Load settings from localStorage
function loadSettings() {
    const savedSettings = localStorage.getItem('quizSettings');
    if (savedSettings) {
        settings = JSON.parse(savedSettings);
    }
    
    // Update UI to reflect current settings
    updateSettingsUI();
}

// Save settings to localStorage
function saveSettings() {
    localStorage.setItem('quizSettings', JSON.stringify(settings));
    showScreen('home-screen');
    alert('Ayarlar başarıyla kaydedildi!');
}

// Update settings UI based on current settings
function updateSettingsUI() {
    // Update word list selection
    document.querySelectorAll('[data-value]').forEach(option => {
        option.classList.remove('settings-option-active');
        
        const settingType = option.getAttribute('onclick').split(',')[1].trim().replace(')', '').replace("'", '').replace("'", '');
        const value = option.getAttribute('data-value');
        
        if (settings[settingType] === value) {
            option.classList.add('settings-option-active');
        }
    });
}

// Select an option in settings
function selectOption(element, settingType) {
    // Remove active class from all options in the same section
    const optionsContainer = element.parentElement;
    optionsContainer.querySelectorAll('.settings-option').forEach(option => {
        option.classList.remove('settings-option-active');
    });
    
    // Add active class to the selected option
    element.classList.add('settings-option-active');
    
    // Update settings
    settings[settingType] = element.getAttribute('data-value');
}

// Load stats from localStorage
function loadStats() {
    const savedStats = localStorage.getItem('quizStats');
    if (savedStats) {
        stats = JSON.parse(savedStats);
    }
}

// Save stats to localStorage
function saveStats() {
    localStorage.setItem('quizStats', JSON.stringify(stats));
}

// Update stats display on the home screen
function updateStatsDisplay() {
    // Update basic stats
    document.getElementById('stats-completed-quizzes').textContent = stats.completedQuizzes;
    document.getElementById('stats-learned-words').textContent = stats.learnedWords;
    
    // Calculate success rate
    let successRate;
    if (stats.successRate !== undefined) {
        // Use server-provided success rate if available
        successRate = stats.successRate;
    } else {
        // Calculate from local stats
        successRate = stats.totalQuestions > 0 
            ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100) 
            : 0;
    }
    document.getElementById('stats-success-rate').textContent = successRate + '%';
    
    // Add average time stat if it doesn't exist
    const statsGrid = document.querySelector('.stats-grid');
    if (statsGrid && !document.getElementById('stats-avg-time') && stats.avgTimePerQuestion) {
        const avgTimeItem = document.createElement('div');
        avgTimeItem.className = 'stats-item';
        avgTimeItem.innerHTML = `
            <div id="stats-avg-time" class="stats-number">${stats.avgTimePerQuestion}s</div>
            <div class="stats-label">Ortalama Süre</div>
        `;
        statsGrid.appendChild(avgTimeItem);
    } else if (document.getElementById('stats-avg-time') && stats.avgTimePerQuestion) {
        document.getElementById('stats-avg-time').textContent = `${stats.avgTimePerQuestion}s`;
    }
    
    // Add due for review stat if it doesn't exist
    if (statsGrid && !document.getElementById('stats-due') && stats.dueForReview !== undefined) {
        const dueItem = document.createElement('div');
        dueItem.className = 'stats-item';
        dueItem.innerHTML = `
            <div id="stats-due" class="stats-number">${stats.dueForReview}</div>
            <div class="stats-label">Tekrar Edilecek</div>
        `;
        statsGrid.appendChild(dueItem);
    } else if (document.getElementById('stats-due') && stats.dueForReview !== undefined) {
        document.getElementById('stats-due').textContent = stats.dueForReview;
    }
}

// Show a specific screen (home, quiz, results, settings)
function showScreen(screenId) {
    // Hide all screens
    document.getElementById('home-screen').style.display = 'none';
    document.getElementById('quiz-screen').style.display = 'none';
    document.getElementById('results-screen').style.display = 'none';
    document.getElementById('settings-screen').style.display = 'none';
    
    // Show the requested screen
    document.getElementById(screenId).style.display = 'block';
    
    // Update active tab
    document.querySelectorAll('.tab-item').forEach(tab => {
        tab.classList.remove('tab-active');
    });
    
    // Find the correct tab to activate
    let tabToActivate;
    if (screenId === 'home-screen') {
        tabToActivate = document.querySelector('.tab-item:nth-child(1)');
    } else if (screenId === 'settings-screen') {
        tabToActivate = document.querySelector('.tab-item:nth-child(3)');
    }
    
    if (tabToActivate) {
        tabToActivate.classList.add('tab-active');
    }
}

// Start a new quiz
function startQuiz(mode) {
    currentQuiz.mode = mode;
    currentQuiz.currentQuestionIndex = 0;
    currentQuiz.score = 0;
    currentQuiz.selectedOptions = [];
    currentQuiz.startTime = new Date();
    currentQuiz.questionStartTime = new Date();
    currentQuiz.questionsTimes = [];
    currentQuiz.totalTime = 0;
    
    // Clear any existing timer
    if (currentQuiz.timer) {
        clearInterval(currentQuiz.timer);
    }
    
    // Generate questions based on the selected word list and difficulty
    generateQuestions();
    
    // Display the first question
    displayQuestion();
    
    // Start timer if in timed mode
    if (settings.timedMode) {
        startTimer();
    }
    
    // Show the quiz screen
    showScreen('quiz-screen');
}

// Start the timer for timed mode
function startTimer() {
    // Add timer element to the quiz header if it doesn't exist
    if (!document.getElementById('quiz-timer')) {
        const timerContainer = document.createElement('div');
        timerContainer.className = 'timer-container';
        timerContainer.innerHTML = `
            <span class="timer-icon">⏱️</span>
            <span id="quiz-timer">0:30</span>
        `;
        document.querySelector('.quiz-header').appendChild(timerContainer);
    }
    
    // Set the initial time
    let timeLeft = settings.timeLimit;
    updateTimerDisplay(timeLeft);
    
    // Start the interval
    currentQuiz.timer = setInterval(() => {
        timeLeft--;
        updateTimerDisplay(timeLeft);
        
        // When time runs out
        if (timeLeft <= 0) {
            clearInterval(currentQuiz.timer);
            
            // Record the time taken for this question
            const timeTaken = settings.timeLimit;
            currentQuiz.questionsTimes.push(timeTaken);
            
            // Move to the next question or finish if this was the last one
            const currentQuestion = currentQuiz.questions[currentQuiz.currentQuestionIndex];
            if (!currentQuestion.answered) {
                // Mark as timed out (wrong answer)
                currentQuestion.answered = true;
                currentQuestion.correct = false;
                
                // Show the correct answer
                const optionButtons = document.querySelectorAll('.option-button');
                const options = currentQuiz.mode === 'en-tr' ? currentQuestion.options_tr : currentQuestion.options_en;
                
                optionButtons.forEach((button, index) => {
                    const optionText = button.querySelector('.option-text');
                    
                    if (currentQuiz.mode === 'en-tr') {
                        // English to Turkish mode
                        if (options[index] === currentQuestion.translation) {
                            // This is the correct option
                            button.classList.add('correct-option');
                            optionText.classList.add('option-text-correct');
                        }
                    } else {
                        // Turkish to English mode
                        if (options[index] === currentQuestion.word) {
                            // This is the correct option
                            button.classList.add('correct-option');
                            optionText.classList.add('option-text-correct');
                        }
                    }
                });
                
                // Wait 1.5 seconds before moving to the next question
                setTimeout(() => {
                    moveToNextQuestion();
                }, 1500);
            }
        }
    }, 1000);
}

// Update the timer display
function updateTimerDisplay(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    const display = `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
    document.getElementById('quiz-timer').textContent = display;
    
    // Change color based on time left
    const timerElement = document.getElementById('quiz-timer');
    if (seconds <= 5) {
        timerElement.style.color = '#F44336'; // Red
    } else if (seconds <= 10) {
        timerElement.style.color = '#FF9800'; // Orange
    } else {
        timerElement.style.color = '#666'; // Default
    }
}

// Generate quiz questions
function generateQuestions() {
    // Get the selected word list
    const wordList = words[settings.wordList] || [];
    
    if (wordList.length === 0) {
        alert('Kelime listesi yüklenemedi. Lütfen sayfayı yenileyin.');
        return;
    }
    
    // Determine the number of questions
    const questionCount = parseInt(settings.questionCount);
    
    // Create a shuffled copy of the word list
    const shuffledList = [...wordList].sort(() => Math.random() - 0.5);
    
    // Take only the required number of questions
    const selectedWords = shuffledList.slice(0, questionCount);
    
    // Create questions array
    currentQuiz.questions = selectedWords.map(word => {
        // Get 3 random incorrect options
        const incorrectOptions = getIncorrectOptions(word, wordList);
        
        // Return the question object with id for API calls
        return {
            id: word.id,  // Add word ID for API calls
            word: word.english,
            translation: word.turkish,
            wordList: word.word_list || settings.wordList,
            // For en-tr mode, we'll show turkish options
            // For tr-en mode, we'll show english options
            // We'll use these in displayQuestion based on mode
            options_tr: shuffleArray([word.turkish, ...incorrectOptions.map(w => w.turkish)]),
            options_en: shuffleArray([word.english, ...incorrectOptions.map(w => w.english)]),
            answered: false,
            correct: false
        };
    });
}

// Get incorrect options for a question
function getIncorrectOptions(correctWord, wordList) {
    // Filter out the correct word
    const filteredList = wordList.filter(word => word.english !== correctWord.english);
    
    // Shuffle the list
    const shuffledList = [...filteredList].sort(() => Math.random() - 0.5);
    
    // Take the first 3 words
    return shuffledList.slice(0, 3);
}

// Shuffle an array (Fisher-Yates algorithm)
function shuffleArray(array) {
    const newArray = [...array];
    for (let i = newArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
}

// Display the current question
function displayQuestion() {
    const currentQuestion = currentQuiz.questions[currentQuiz.currentQuestionIndex];
    
    // Update progress display
    document.getElementById('quiz-progress').textContent = `Soru ${currentQuiz.currentQuestionIndex + 1}/${currentQuiz.questions.length}`;
    document.getElementById('quiz-score').textContent = `Skor: ${currentQuiz.score}`;
    
    // Update progress bar
    const progressPercentage = ((currentQuiz.currentQuestionIndex) / currentQuiz.questions.length) * 100;
    document.getElementById('progress-bar').style.width = `${progressPercentage}%`;
    
    // Update question label based on quiz mode
    if (currentQuiz.mode === 'en-tr') {
        document.getElementById('question-label').textContent = 'İngilizce kelimenin Türkçe karşılığı nedir?';
        document.getElementById('question-word').textContent = currentQuestion.word;
    } else {
        document.getElementById('question-label').textContent = 'Türkçe kelimenin İngilizce karşılığı nedir?';
        document.getElementById('question-word').textContent = currentQuestion.translation;
    }
    
    // Generate options
    const optionsContainer = document.getElementById('options-container');
    optionsContainer.innerHTML = '';
    
    // Choose the correct options array based on the mode
    const options = currentQuiz.mode === 'en-tr' ? currentQuestion.options_tr : currentQuestion.options_en;
    
    options.forEach((option, index) => {
        const optionButton = document.createElement('div');
        optionButton.className = 'option-button';
        optionButton.innerHTML = `<div class="option-text">${option}</div>`;
        optionButton.onclick = function() {
            selectAnswer(index);
        };
        
        optionsContainer.appendChild(optionButton);
    });
}

// Handle answer selection
function selectAnswer(optionIndex) {
    // Get the current question
    const currentQuestion = currentQuiz.questions[currentQuiz.currentQuestionIndex];
    
    // If already answered, do nothing
    if (currentQuestion.answered) {
        return;
    }
    
    // Calculate time taken for this question
    const now = new Date();
    const timeTaken = (now - currentQuiz.questionStartTime) / 1000; // in seconds
    currentQuiz.questionsTimes.push(timeTaken);
    currentQuestion.timeTaken = timeTaken;
    
    // Stop timer if in timed mode
    if (settings.timedMode && currentQuiz.timer) {
        clearInterval(currentQuiz.timer);
    }
    
    // Mark as answered
    currentQuestion.answered = true;
    
    // Get the options and selected option based on mode
    const options = currentQuiz.mode === 'en-tr' ? currentQuestion.options_tr : currentQuestion.options_en;
    const selectedOption = options[optionIndex];
    
    // Check if the answer is correct
    const isCorrect = currentQuiz.mode === 'en-tr' 
        ? selectedOption === currentQuestion.translation
        : selectedOption === currentQuestion.word;
    
    // Update score
    if (isCorrect) {
        currentQuiz.score++;
        currentQuestion.correct = true;
    }
    
    // Store the selected option
    currentQuiz.selectedOptions[currentQuiz.currentQuestionIndex] = {
        selectedIndex: optionIndex,
        isCorrect: isCorrect,
        timeTaken: timeTaken
    };
    
    // Update the UI to show correct/incorrect
    const optionButtons = document.querySelectorAll('.option-button');
    
    optionButtons.forEach((button, index) => {
        const optionText = button.querySelector('.option-text');
        
        if (currentQuiz.mode === 'en-tr') {
            // English to Turkish mode
            if (options[index] === currentQuestion.translation) {
                // This is the correct option
                button.classList.add('correct-option');
                optionText.classList.add('option-text-correct');
            } else if (index === optionIndex && !isCorrect) {
                // This is the wrong selected option
                button.classList.add('wrong-option');
                optionText.classList.add('option-text-wrong');
            }
        } else {
            // Turkish to English mode
            if (options[index] === currentQuestion.word) {
                // This is the correct option
                button.classList.add('correct-option');
                optionText.classList.add('option-text-correct');
            } else if (index === optionIndex && !isCorrect) {
                // This is the wrong selected option
                button.classList.add('wrong-option');
                optionText.classList.add('option-text-wrong');
            }
        }
    });
    
    // Wait 1.5 seconds before moving to the next question
    setTimeout(() => {
        moveToNextQuestion();
    }, 1500);
}

// Move to the next question or finish the quiz
function moveToNextQuestion() {
    // Reset timer if in timed mode
    if (settings.timedMode && currentQuiz.timer) {
        clearInterval(currentQuiz.timer);
    }
    
    // Move to the next question
    currentQuiz.currentQuestionIndex++;
    
    // Check if we've reached the end of the quiz
    if (currentQuiz.currentQuestionIndex >= currentQuiz.questions.length) {
        finishQuiz();
    } else {
        // Reset question start time
        currentQuiz.questionStartTime = new Date();
        
        // Display the next question
        displayQuestion();
        
        // Restart timer if in timed mode
        if (settings.timedMode) {
            startTimer();
        }
    }
}

// Finish the quiz and show results
async function finishQuiz() {
    // Stop the timer if active
    if (currentQuiz.timer) {
        clearInterval(currentQuiz.timer);
    }
    
    // Record end time
    currentQuiz.endTime = new Date();
    currentQuiz.totalTime = Math.floor((currentQuiz.endTime - currentQuiz.startTime) / 1000); // in seconds
    
    // Update statistics in memory
    stats.completedQuizzes++;
    stats.correctAnswers += currentQuiz.score;
    stats.totalQuestions += currentQuiz.questions.length;
    
    // Calculate average time per question
    if (currentQuiz.questionsTimes.length > 0) {
        const avgTime = currentQuiz.questionsTimes.reduce((a, b) => a + b, 0) / currentQuiz.questionsTimes.length;
        stats.avgTimePerQuestion = Math.round(avgTime * 10) / 10; // Round to 1 decimal
    }
    
    // Update learned words based on correctly answered questions
    const newLearnedWords = currentQuiz.questions.filter(q => q.correct).length;
    stats.learnedWords += newLearnedWords;
    
    // Save statistics locally
    saveStats();
    
    // Update statistics display
    updateStatsDisplay();
    
    // Update results screen
    document.getElementById('results-score').textContent = `Skorunuz: ${currentQuiz.score}/${currentQuiz.questions.length}`;
    
    const percentage = Math.round((currentQuiz.score / currentQuiz.questions.length) * 100);
    document.getElementById('results-percentage').textContent = `${percentage}%`;
    
    let timeDisplay = '';
    if (currentQuiz.totalTime) {
        const minutes = Math.floor(currentQuiz.totalTime / 60);
        const seconds = currentQuiz.totalTime % 60;
        timeDisplay = `<div class="results-time">Toplam Süre: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}</div>`;
        
        // Add to the results screen if it doesn't exist
        if (!document.querySelector('.results-time')) {
            document.getElementById('results-percentage').insertAdjacentHTML('afterend', timeDisplay);
        } else {
            document.querySelector('.results-time').textContent = `Toplam Süre: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        }
    }
    
    // Save results to database if user is logged in
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                        document.querySelector('.user-info') !== null;
    
    if (isLoggedIn) {
        try {
            const response = await fetch('/api/quiz-results', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    mode: currentQuiz.mode,
                    difficulty: settings.difficulty,
                    wordList: settings.wordList,
                    questions: currentQuiz.questions.map(q => ({
                        word: q.word,
                        translation: q.translation,
                        correct: q.correct || false,
                        timeTaken: q.timeTaken || 0
                    })),
                    score: currentQuiz.score,
                    timeTaken: currentQuiz.totalTime
                })
            });
            
            if (!response.ok) {
                console.error('Failed to save quiz results to server');
            }
        } catch (error) {
            console.error('Error saving quiz results:', error);
        }
    }
    
    // Generate questions review section
    const questionsReview = document.getElementById('questions-review');
    questionsReview.innerHTML = ''; // Clear previous content
    
    // Create a review item for each question
    currentQuiz.questions.forEach((question, index) => {
        const reviewItem = document.createElement('div');
        reviewItem.className = 'review-question';
        
        // Get the word ID for API calls (stored in question object)
        const wordId = question.id;
        
        // Determine which is the question and which is the answer based on quiz mode
        const questionText = currentQuiz.mode === 'en-tr' ? question.word : question.translation;
        const answerText = currentQuiz.mode === 'en-tr' ? question.translation : question.word;
        
        // Create HTML for the review item
        reviewItem.innerHTML = `
            <div class="review-question-word">
                ${questionText}
                <span class="play-pronunciation" onclick="playQuizPronunciation(${wordId})">🔊</span>
            </div>
            <div class="review-question-translation">${answerText}</div>
            <div class="review-question-result ${question.correct ? 'review-correct' : 'review-incorrect'}">
                ${question.correct ? '✓ Doğru' : '✗ Yanlış'}
            </div>
            <div class="review-controls">
                <button class="review-examples-btn" onclick="showQuizExamples(${wordId}, ${index})">Örnekler</button>
                <button class="review-favorite-btn" onclick="addToFavoritesFromQuiz('${question.word}', '${question.translation}', '${question.wordList}')">Favorilere Ekle</button>
            </div>
            <div id="quiz-examples-${index}" class="review-examples" style="display: none;">
                <div class="examples-loading">Örnekler yükleniyor...</div>
            </div>
        `;
        
        questionsReview.appendChild(reviewItem);
    });
    
    // Show results screen
    showScreen('results-screen');
}

// Start a new quiz with the same settings
function startNewQuiz() {
    startQuiz(currentQuiz.mode);
}

// Quit the current quiz and go back to home
function quitQuiz() {
    if (confirm('Quiz\'i sonlandırmak istediğinizden emin misiniz?')) {
        showScreen('home-screen');
    }
}

// Show leaderboard
function showLeaderboard() {
    window.location.href = '/leaderboard';
}

// Load favorite words from the server
async function loadFavorites() {
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('.user-info') !== null;
    
    if (!isLoggedIn) {
        console.log('User not logged in, favorites not available');
        return;
    }
    
    try {
        const response = await fetch('/api/favorites');
        if (!response.ok) {
            throw new Error('Failed to load favorites');
        }
        
        const favorites = await response.json();
        
        // Update stats
        stats.favorites = favorites;
        
        // Display favorites if we're on the home screen
        const favoritesSection = document.getElementById('favorites-section');
        const favoritesList = document.getElementById('favorites-list');
        const favoritesCount = document.getElementById('favorites-count');
        
        if (favoritesSection && favoritesList) {
            if (favorites.length === 0) {
                favoritesSection.style.display = 'none';
                return;
            }
            
            favoritesSection.style.display = 'block';
            favoritesCount.textContent = `${favorites.length} kelime`;
            
            favoritesList.innerHTML = '';
            favorites.forEach(fav => {
                const favElement = document.createElement('div');
                favElement.className = 'favorite-word';
                favElement.innerHTML = `
                    <div class="favorite-english">${fav.english}</div>
                    <div class="favorite-turkish">${fav.turkish}</div>
                    <div class="remove-favorite" onclick="removeFavorite(${fav.favorite_id})">×</div>
                `;
                favoritesList.appendChild(favElement);
            });
        }
    } catch (error) {
        console.error('Error loading favorites:', error);
    }
}

// Add a word to favorites
async function addToFavorites(english, turkish, wordList) {
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('.user-info') !== null;
    
    if (!isLoggedIn) {
        alert('Favorilere eklemek için giriş yapmanız gerekiyor.');
        return;
    }
    
    try {
        const response = await fetch('/api/favorites', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                english,
                turkish,
                word_list: wordList
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to add to favorites');
        }
        
        const result = await response.json();
        
        // Reload favorites
        await loadFavorites();
        
        alert('Kelime favorilere eklendi!');
    } catch (error) {
        console.error('Error adding to favorites:', error);
        alert('Favorilere eklerken bir hata oluştu.');
    }
}

// Remove a word from favorites
async function removeFavorite(favoriteId) {
    try {
        const response = await fetch('/api/favorites', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                favorite_id: favoriteId
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to remove from favorites');
        }
        
        // Reload favorites
        await loadFavorites();
    } catch (error) {
        console.error('Error removing from favorites:', error);
        alert('Favorilerden kaldırırken bir hata oluştu.');
    }
}

// Load due words for spaced repetition
async function loadDueWords() {
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('.user-info') !== null;
    
    if (!isLoggedIn) {
        return;
    }
    
    try {
        const response = await fetch('/api/due-words');
        if (!response.ok) {
            throw new Error('Failed to load due words');
        }
        
        const dueWords = await response.json();
        
        // Update stats
        stats.dueForReview = dueWords.length;
        
        // Display due words section if we're on the home screen
        const reviewSection = document.getElementById('review-section');
        const reviewContent = document.getElementById('review-content');
        const reviewCount = document.getElementById('review-count');
        
        if (reviewSection && reviewContent) {
            if (dueWords.length === 0) {
                reviewSection.style.display = 'none';
                return;
            }
            
            reviewSection.style.display = 'block';
            reviewCount.textContent = `${dueWords.length} kelime`;
            
            // Add a button to start review
            reviewContent.innerHTML = `
                <button class="primary-button" onclick="window.location.href='/review'">
                    Tekrarı Başlat
                </button>
            `;
        }
    } catch (error) {
        console.error('Error loading due words:', error);
    }
}

// Load user's statistics from the server
async function loadUserStats() {
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('.user-info') !== null;
    
    if (!isLoggedIn) {
        return;
    }
    
    try {
        const response = await fetch('/api/stats');
        if (!response.ok) {
            throw new Error('Failed to load user stats');
        }
        
        const userStats = await response.json();
        
        // Update stats
        stats.completedQuizzes = userStats.completed_quizzes;
        stats.learnedWords = userStats.learned_words;
        stats.successRate = userStats.success_rate;
        stats.avgTimePerQuestion = userStats.average_time;
        stats.dueForReview = userStats.due_for_review;
        
        // Update the display
        updateStatsDisplay();
    } catch (error) {
        console.error('Error loading user stats:', error);
    }
}

// Show example sentences for a quiz word
async function showQuizExamples(wordId, index) {
    const examplesContainer = document.getElementById(`quiz-examples-${index}`);
    
    // Toggle visibility
    if (examplesContainer.style.display === 'none') {
        examplesContainer.style.display = 'block';
        
        try {
            // Fetch examples from the API
            const response = await fetch(`/api/examples/${wordId}`);
            const examples = await response.json();
            
            // Clear loading message
            examplesContainer.innerHTML = '';
            
            if (examples.length === 0) {
                examplesContainer.innerHTML = '<div class="no-examples">Bu kelime için örnek cümle bulunamadı.</div>';
                return;
            }
            
            // Display examples
            const examplesList = document.createElement('div');
            examplesList.className = 'examples-list';
            
            examples.forEach(example => {
                const exampleItem = document.createElement('div');
                exampleItem.className = 'example-item';
                exampleItem.innerHTML = `
                    <div class="example-english">${example.english}</div>
                    <div class="example-turkish">${example.turkish}</div>
                `;
                examplesList.appendChild(exampleItem);
            });
            
            examplesContainer.appendChild(examplesList);
            
        } catch (error) {
            console.error('Error loading examples:', error);
            examplesContainer.innerHTML = '<div class="examples-error">Örnekler yüklenirken bir hata oluştu.</div>';
        }
    } else {
        examplesContainer.style.display = 'none';
    }
}

// Play pronunciation audio for a quiz word
async function playQuizPronunciation(wordId) {
    try {
        // Get or generate pronunciation URL
        const response = await fetch(`/api/pronunciation/${wordId}`);
        const data = await response.json();
        
        if (data.url) {
            // Create and play an audio element
            const audio = new Audio(data.url);
            audio.play();
        } else {
            console.error('Pronunciation not available');
        }
    } catch (error) {
        console.error('Error playing pronunciation:', error);
    }
}

// Add a word to favorites from quiz results
async function addToFavoritesFromQuiz(english, turkish, wordList) {
    await addToFavorites(english, turkish, wordList);
}
